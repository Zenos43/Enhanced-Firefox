// ==UserScript==
// @name         Youtube Player perf (fixed)
// @version      1.0
// @description  Optimizes animation calls for lower GPU/CPU consumption
// @namespace    Zenos43
// @author       Zenos43
// @match        https://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant        none
// @run-at       document-start
// @license      MIT
// ==/UserScript==

/* global _yt_player */

(() => {
    "use strict";

    const scaleX0 = Symbol("scaleX(0)");
    const scaleX1 = Symbol("scaleX(1)");

    // Updated internal YouTube identifiers (verify from latest base.js)
    const PLAYER_CONSTRUCTOR = "sV"; // Confirm if still valid
    const ATTR_UPDATE = "yo";        // Confirm if still valid
    const UPDATE_INTERNAL = "v";     // Confirm if still valid

    function checks(ytp) {
        return ytp[UPDATE_INTERNAL] && ytp[PLAYER_CONSTRUCTOR] && ytp[ATTR_UPDATE];
    }

    function modifyBase() {
        console.log("Overriding _yt_player methods");

        if (!window._yt_player) {
            console.error("YT player not available, load order is wrong");
            return;
        }

        if (!checks(window._yt_player)) {
            console.warn("YouTube Player Perf: Incompatible YouTube version");
            return;
        }

        const OriginalPlayer = _yt_player[PLAYER_CONSTRUCTOR];
        const originalUpdateAttr = _yt_player[ATTR_UPDATE];

        // Player constructor override
        _yt_player[PLAYER_CONSTRUCTOR] = function(...args) {
            OriginalPlayer.apply(this, args);
            this.__updateCache = new Map();
            this.update = function(a) {
                const b = _yt_player[UPDATE_INTERNAL](Object.keys(a));
                for (let c of b) {
                    if (this.__updateCache.get(c) !== a[c]) {
                        this.updateValue(c, a[c]);
                        this.__updateCache.set(c, a[c]);
                    }
                }
            };
        };
        _yt_player[PLAYER_CONSTRUCTOR].prototype = OriginalPlayer.prototype;

        // Attribute update override
        let headElement = null;
        _yt_player[ATTR_UPDATE] = function(el, attr, value) {
            if (attr === "transform" && value.includes("scaleX")) {
                if (value === "scaleX(0)" && el[scaleX0]) return;
                if (value === "scaleX(1)" && el[scaleX1]) return;

                if (value === "scaleX(0)") {
                    el[scaleX0] = true;
                    el[scaleX1] = false;
                } else {
                    el[scaleX0] = false;
                    el[scaleX1] = true;
                }

                if (headElement === el) return;
                headElement = el;
            }
            originalUpdateAttr.call(this, el, attr, value);
            headElement = null;
        };
    }

    // MutationObserver to detect base.js load
    const observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.tagName === 'SCRIPT' && node.src.includes('/base.js')) {
                    node.addEventListener('load', modifyBase);
                    observer.disconnect();
                    return;
                }
            }
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });
})();