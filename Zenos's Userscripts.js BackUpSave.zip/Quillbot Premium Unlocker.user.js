// ==UserScript==
// @name         Quillbot Premium Unlocker
// @namespace    quillbot.taozhiyu.gitee.io
// @version      0.3.3
// @description  Unlocks Quillbot Premium features with improved stability and compatibility
// @author       longkidkoolstar
// @match        https://quillbot.com/*
// @icon         https://quillbot.com/favicon.png
// @require      https://greasyfork.org/scripts/455943-ajaxhooker/code/ajaxHooker.js?version=1124435
// @run-at       document-start
// @grant        none
// @license      none
// @downloadURL https://update.greasyfork.org/scripts/465276/Quillbot%20Premium%20Unlocker.user.js
// @updateURL https://update.greasyfork.org/scripts/465276/Quillbot%20Premium%20Unlocker.meta.js
// ==/UserScript==
/* global ajaxHooker*/
(function() {
    'use strict';
    
    // Configuration
    const DEBUG = false; // Enable for additional console logging
    
    // Intercept API responses to enable premium features
    ajaxHooker.hook(request => {
        if (request.url.endsWith('get-account-details')) {
            // Log interception if debug mode enabled
            DEBUG && console.log('[QuillbotUnlocker] Intercepting account details request');
            
            request.response = response => {
                const responseData = JSON.parse(response.responseText);
                const accountData = "data" in responseData ? responseData.data : responseData;
                
                // Set premium status flags
                accountData.profile.accepted_premium_modes_tnc = true;
                accountData.profile.premium = true;
                
                // Update response with modified data
                response.responseText = JSON.stringify("data" in responseData ? 
                    (responseData.data = accountData, responseData) : accountData);
                
                DEBUG && console.log('[QuillbotUnlocker] Premium status enabled successfully');
            };
        }
    });
    
    // Initialize notification UI after page loads
    window.addEventListener('load', initializeNotification);
    
    // Create and display the community notification
    function initializeNotification() {
        const notificationElement = createNotificationElement();
        document.body.appendChild(notificationElement);
        
        DEBUG && console.log('[QuillbotUnlocker] Notification displayed');
    }
    
    // Helper function to create notification UI
    function createNotificationElement() {
        // Create container
        const popup = document.createElement('div');
        popup.style.position = 'fixed';
        popup.style.bottom = '20px';
        popup.style.right = '20px';
        popup.style.padding = '15px';
        popup.style.backgroundColor = '#f9f9f9';
        popup.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
        popup.style.border = '1px solid #ccc';
        popup.style.borderRadius = '8px';
        popup.style.zIndex = '10000';
        popup.style.fontFamily = 'Arial, sans-serif';
        popup.style.color = '#333';
        popup.style.textAlign = 'center';
        
        // Add message
        const message = document.createElement('p');
        message.textContent = 'Join our Discord community for discussions, support, and additional resources, including User-Scripts not posted on Greasyfork!';
        message.style.margin = '0 0 10px';
        
        // Add link
        const link = document.createElement('a');
        link.href = 'https://discord.gg/JrweGzdjwA';
        link.textContent = 'Join Discord';
        link.style.color = '#007bff';
        link.style.textDecoration = 'none';
        link.style.fontWeight = 'bold';
        link.target = '_blank';
        link.addEventListener('mouseover', () => link.style.textDecoration = 'underline');
        link.addEventListener('mouseout', () => link.style.textDecoration = 'none');
        
        // Add close button
        const closeButton = document.createElement('button');
        closeButton.textContent = '✖';
        closeButton.style.position = 'absolute';
        closeButton.style.top = '5px';
        closeButton.style.right = '5px';
        closeButton.style.background = 'none';
        closeButton.style.border = 'none';
        closeButton.style.cursor = 'pointer';
        closeButton.style.fontSize = '16px';
        closeButton.style.color = '#333';
        closeButton.addEventListener('click', () => {
            document.body.removeChild(popup);
        });
        
        // Assemble elements
        popup.appendChild(message);
        popup.appendChild(link);
        popup.appendChild(closeButton);
        
        return popup;
    }
})();