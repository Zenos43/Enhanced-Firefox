// ==UserScript==
// @name         nhentai-add-month-filter
// @namespace    https://google.fr
// @version      0.1
// @description  add month filter
// @author       Hynauts
// @match        https://nhentai.net/search/*
// @match        https://nhentai.net/tag/*
// @match        https://nhentai.net/artist/*
// @match        https://nhentai.net/character/*
// @match        https://nhentai.net/parody/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    var a = document.getElementsByClassName("sort-type");
    var q = a[1].innerHTML.substring(a[1].innerHTML.indexOf("?q=") + 3, a[1].innerHTML.indexOf("&amp"))

    if (/\/search\/\.*/.test (location.pathname) ) {
        // Run code for edit pages
        a[1].innerHTML = `<span class="sort-name">Popular:</span><a href="/search/?q=${q}&amp;sort=popular-today">today</a><a href="/search/?q=${q}&amp;sort=popular-week">week</a><a href="/search/?q=${q}&amp;sort=popular-month">month</a><a href="/search/?q=${q}&amp;sort=popular">all time</a>`

    }
    else {
        // Run code for delete pages
        a[1].innerHTML = `<span class="sort-name">Popular:</span><a href="popular-today">today</a><a href="popular-week">week</a><a href="popular-month">month</a><a href="popular">all time</a>`
    }

})();