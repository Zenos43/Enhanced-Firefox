// ==UserScript==
// @name         Advanced YouTube Age Restriction Bypass
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Bypass YouTube age restrictions for test purposes only.
// @author       Your Name
// @match        *://www.youtube.com/*
// @grant        none
// @downloadURL https://update.greasyfork.org/scripts/521089/Advanced%20YouTube%20Age%20Restriction%20Bypass.user.js
// @updateURL https://update.greasyfork.org/scripts/521089/Advanced%20YouTube%20Age%20Restriction%20Bypass.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // Helper function to log debug messages
    function log(message) {
        console.log(`[YouTube Bypass]: ${message}`);
    }

    // Hook into YouTube's internal API requests
    (function interceptXHR() {
        const originalOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url) {
            if (url.includes('/youtubei/v1/player')) {
                log('Intercepted YouTube player API request');
                this.addEventListener('readystatechange', function() {
                    if (this.readyState === 4 && this.status === 200) {
                        try {
                            const response = JSON.parse(this.responseText);
                            if (response.playabilityStatus?.status === 'AGE_RESTRICTED') {
                                log('Detected age-restricted video. Modifying response...');
                                response.playabilityStatus.status = 'OK';
                                response.playabilityStatus.reason = '';
                                Object.defineProperty(this, 'responseText', { value: JSON.stringify(response) });
                            }
                        } catch (e) {
                            log('Error modifying API response: ' + e.message);
                        }
                    }
                });
            }
            return originalOpen.apply(this, arguments);
        };
    })();

    // MutationObserver to monitor dynamic page changes (SPA handling)
    const observer = new MutationObserver(() => {
        if (document.querySelector('ytd-watch-flexy[is-restricted]')) {
            log('Detected restricted video player. Attempting bypass...');
            injectOverrideScript();
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Function to inject an override script directly into the page
    function injectOverrideScript() {
        const script = document.createElement('script');
        script.innerHTML = `
            (function() {
                const originalPlayer = window.ytPlayerConfig;
                if (originalPlayer && originalPlayer.args) {
                    originalPlayer.args.raw_player_response.playabilityStatus.status = 'OK';
                    console.log('[YouTube Bypass]: Player configuration modified.');
                }
            })();
        `;
        document.body.appendChild(script);
        script.remove();
    }

    log('Script initialized. Watching for restricted videos...');
})();