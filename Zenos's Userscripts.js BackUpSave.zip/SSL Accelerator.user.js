// ==UserScript==
// @name           SSL Accelerator
// @description    Speculatively performs SSL/TLS handshakes for hovered links
// @version        1.0
// @include        *
// ==/UserScript==

(function() {
    const connectedHosts = new Set();
    const handshakeTimes = new Map();
    let handshakeTimer = null;
    const currentHost = window.location.hostname;

    function onLinkHover(event) {
        const anchor = event.target.closest("a[href^='https://']");
        if (!anchor) return;
        const targetHost = anchor.hostname;
        if (targetHost === currentHost || connectedHosts.has(targetHost)) return;
        if (handshakeTimer) clearTimeout(handshakeTimer);
        handshakeTimer = setTimeout(() => {
            handshakeTimes.set(targetHost, Date.now());
            fetch(`https://${targetHost}`, {
                method: "HEAD",
                mode: "no-cors"
            })
            .then(() => {
                //console.log(`Connected to "${targetHost}"`);
            })
            .catch((error) => {
                //console.error(`Error connecting to "${targetHost}":`, error);
            });
            connectedHosts.add(targetHost);
        }, 100);
    }
    function onLinkLeave() {
        if (handshakeTimer) clearTimeout(handshakeTimer);
    }
    document.body.addEventListener("mouseover", onLinkHover, { passive: true });
    document.body.addEventListener("mouseout", onLinkLeave, { passive: true });
})();// ==UserScript==
// @name        New script
// @namespace   Violentmonkey Scripts
// @match       *://example.org/*
// @grant       none
// @version     1.0
// @author      -
// @description 4/6/2025, 8:08:28 AM
// ==/UserScript==
