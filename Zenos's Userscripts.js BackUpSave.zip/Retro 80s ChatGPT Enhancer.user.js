// ==UserScript==
// @name         Retro 80s ChatGPT Enhancer
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  Turn ChatGPT into a retro 80s style website
// @match        https://chatgpt.com/*
// @grant        GM_addStyle
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/501726/Retro%2080s%20ChatGPT%20Enhancer.user.js
// @updateURL https://update.greasyfork.org/scripts/501726/Retro%2080s%20ChatGPT%20Enhancer.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // Function to force dark mode (unchanged)
    function forceDarkMode() {
        document.querySelector('html').classList.add('dark');
        localStorage.setItem('theme', 'dark');
    }

    // Run forceDarkMode immediately and then every second
    forceDarkMode();
    setInterval(forceDarkMode, 1000);

    // Add custom CSS styles for retro look
    GM_addStyle(`
        /* Base styles (unchanged) */
        body, .dark, .dark .bg-white, .dark .bg-gray-50, .dark .bg-gray-100 {
            background-color: #000 !important;
            color: #0f0 !important;
            font-family: 'Courier New', Courier, monospace !important;
        }

        .dark .border-gray-100, .dark .border-gray-200 {
            border-color: #0f0 !important;
        }

        /* Apply border-radius globally */
        *, *::before, *::after {
            border-radius: 4px !important;
        }

        /* Improved button styles */
        button, .dark button {
            background-color: #000 !important;
            color: #0f0 !important;
            border: 1px solid #0f0 !important;
            border-radius: 4px !important;
            transition: all 0.3s ease;
        }

        /* Specific styles for the targeted button */
        .relative a.btn.btn-primary {
            background-color: #000 !important;
            color: #0f0 !important;
            border: 1px solid #0f0 !important;
            border-radius: 4px !important;
            transition: all 0.3s ease;
        }

        .relative a.btn.btn-primary:hover {
            background-color: #0f0 !important;
            color: #000 !important;
            box-shadow: 0 0 1px #0f0, inset 0 0 1px #000;
            text-shadow: 0 0 2px #000;
        }

        /* New hover effects for buttons */
        button:hover, .dark button:hover {
            background-color: #0f0 !important;
            color: #000 !important;
            box-shadow: 0 0 10px rgba(0, 255, 0, 0.7), inset 0 0 5px rgba(0, 0, 0, 0.5);
            text-shadow: 0 0 3px rgba(0, 0, 0, 0.7);
        }

        /* Hover effect for buttons including svg */
        button:hover svg, .dark button:hover svg {
            fill: #000 !important;
            color: #000 !important;
        }

        /* New styles for the switch button */
        [role="switch"] {
            border: 2px solid #0f0 !important;
            background-color: #0f0 !important;
        }

        [role="switch"] span {
            background-color: #0f0 !important;
            box-shadow: 0 0 5px #0f0 !important;
        }

        [role="switch"][aria-checked="true"] {
            background-color: #0f0 !important;
        }

        [role="switch"][aria-checked="true"] span {
            background-color: #0f0 !important;
            box-shadow: 0 0 5px #000 !important;
        }

        /* Input and textarea styles (unchanged) */
        input, textarea, .dark input, .dark textarea {
            background-color: #000 !important;
            color: #0f0 !important;
            border: 1px solid #0f0 !important;
            border-radius: 4px !important;
        }

        /* Link hover effect (unchanged) */
        a:hover, .dark a:hover {
            color: #ff0 !important;
            text-shadow: 0 0 5px #ff0;
        }

        /* Glow effect for text (unchanged) */
        .text-base, .markdown, .dark .text-base, .dark .markdown {
            color: #0f0 !important;
            text-shadow: 0 0 5px #0f0;
        }

        /* Subtle retro effect for images */
        img {
            filter: sepia(40%) hue-rotate(20deg) saturate(120%) contrast(120%) !important;
            border: 1px solid #9f9 !important;
            box-shadow: 0 0 5px #9f9 !important;
        }

        /* Apply green color to all SVGs */
        svg {
            fill: #0f0 !important;
            color: #0f0 !important;
        }

        /* Navigation bar button styles */
        .no-scrollbar .cursor-pointer {
            background-color: #000 !important;
            color: #0f0 !important;
            border: 1px solid #0f0 !important;
            border-radius: 4px !important;
            transition: all 0.3s ease;
        }

        /* Scanlines effect (unchanged) */
        body::after {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 255, 0, 0.03),
                rgba(0, 255, 0, 0.03) 1px,
                transparent 1px,
                transparent 2px
            );
            pointer-events: none;
            z-index: 9999;
        }

        /* Ensure all icons are visible (unchanged) */
        .dark .text-gray-400, .dark .text-gray-500, .dark .text-gray-600, .dark .text-gray-700 {
            color: #0f0 !important;
        }
    `);

    // Function to apply retro effects to new elements (unchanged)
    function applyRetroEffects() {
        document.querySelectorAll('img').forEach(img => {
            img.style.filter = 'sepia(100%) hue-rotate(50deg) saturate(200%) contrast(150%)';
            img.style.border = '1px solid #0f0';
            img.style.boxShadow = '0 0 10px #0f0';
        });
    }

    // Run the function initially and then every second to catch new elements
    applyRetroEffects();
    setInterval(applyRetroEffects, 1000);
})();
