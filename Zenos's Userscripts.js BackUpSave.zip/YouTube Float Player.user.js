// ==UserScript==
// @name YouTube Float Player
// @namespace YouTube Float Player
// @version 1.0.1
// @description Floating YouTube player with proper progress bar scaling
// @author Zenos43
// @match *://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant none
// ==/UserScript==

(function() {
'use strict';

const doc = document;
const win = window;
let floatheight = 0;

function docsearch(query) {
    return doc.evaluate(query, doc, null, 7, null);
}

function insertStyle(str, id) {
    let styleNode = doc.getElementById(id);
    if (!styleNode) {
        styleNode = doc.createElement("style");
        styleNode.id = id;
        styleNode.setAttribute("type", "text/css");
        doc.head.appendChild(styleNode);
    }
    if (styleNode.textContent !== str) {
        styleNode.textContent = str;
    }
}

function reset_float() {
    const page = docsearch("//ytd-page-manager/ytd-watch-flexy").snapshotItem(0);
    if (!page) return;

    if (page.hasAttribute("float")) {
        setTimeout(() => win.dispatchEvent(new Event('resize')), 100);
    }
    page.removeAttribute("float");
    page.parentNode.parentNode.removeAttribute("float");
    insertStyle("", "ytpc_style_float");
    floatheight = 0;
}

function float() {
    if (!win.location.href.includes("watch?")) {
        reset_float();
        return;
    }

    const page = docsearch("//ytd-page-manager/ytd-watch-flexy").snapshotItem(0);
    if (!page) return;

    if (page.hasAttribute("fullscreen")) {
        reset_float();
        return;
    }

    const vid = page.hasAttribute("theater") ?
        docsearch("//*[@id='full-bleed-container']").snapshotItem(0) :
        docsearch("//*[@id='primary-inner']/*[@id='player']").snapshotItem(0);

    if (!vid) return;

    const rect = vid.getBoundingClientRect();
    const vheight = rect.bottom - rect.top;

    const W = doc.documentElement.clientWidth;
    const H = doc.documentElement.clientHeight;
    const height = 450;  // Increased height
    const width = 800;   // Increased width

    const infloat = page.hasAttribute("float");
    if (!infloat) floatheight = vheight;

    const thres = floatheight > 0 ? floatheight - 220 : -1;
    const scrollY = win.pageYOffset;

    if (scrollY >= thres && thres > 0) {
        page.setAttribute("float", "");
        page.parentNode.parentNode.setAttribute("float", "");

        const hoff = 20;     // Left offset
        const voff = 20;     // Top offset
        const rtl = doc.body.getAttribute('dir') === 'rtl';
        const lroff = rtl ?
            "right:20px !important;" :
            `left: ${hoff}px !important;`;

        insertStyle(`
            ytd-watch-flexy[float] #player-container {
                position: fixed !important;
                top: ${voff}px !important;
                ${lroff}
                width: ${width}px !important;
                height: ${height}px !important;
                z-index: 1000 !important;
            }
            ytd-watch-flexy[float] .html5-main-video {
                width: ${width}px !important;
                height: ${height}px !important;
            }
            ytd-watch-flexy[float] .ytp-progress-bar-container {
                width: calc(100% - 12px) !important;
                margin: 0 6px !important;
            }
            ytd-watch-flexy[float] .ytp-chapters {
                width: 100% !important;
            }
            ytd-watch-flexy[float] .ytp-progress-bar {
                width: 100% !important;
            }
            ytd-watch-flexy[float] .ytp-chapter-hover-container {
                width: 100% !important;
            }
        `, "ytpc_style_float");
    } else {
        reset_float();
    }
}

// Event listeners
['focus', 'blur', 'resize', 'scroll'].forEach(event => {
    win.addEventListener(event, float, false);
});

setInterval(float, 1000);
float();
})();