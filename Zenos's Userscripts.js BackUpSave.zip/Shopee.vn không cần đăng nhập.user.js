// ==UserScript==
// @name         Shopee.vn không cần đăng nhập
// @namespace    Shopee without login
// @version      1.8.2
// @description  Lướt Shopee.vn không cần đăng nhập
// @author       kylyte
// @license      GPL-3.0
// @match        https://shopee.vn/
// @match        https://shopee.vn/*
// @run-at       document-end
// @grant        none
// @downloadURL https://update.greasyfork.org/scripts/534195/Shopeevn%20kh%C3%B4ng%20c%E1%BA%A7n%20%C4%91%C4%83ng%20nh%E1%BA%ADp.user.js
// @updateURL https://update.greasyfork.org/scripts/534195/Shopeevn%20kh%C3%B4ng%20c%E1%BA%A7n%20%C4%91%C4%83ng%20nh%E1%BA%ADp.meta.js
// ==/UserScript==

(function() {
    'use strict';

    const selectors = [
        'a.contents',
        'a.item-card-special__link.product-shop-hot-sales__item',
        'div.sGJRNY.neoRB5',
        'li.image-carousel__item a.contents',
        'li.EFXloV',
        'div.product-recommend-items__item-wrapper a[href]'
    ];

    if (/[\?&](d_id|uls_trackid)=/.test(location.search)) {
        location.replace(location.origin + location.pathname);
    }

    function cleanHref(a) {
        if (!a?.href) return;
        try {
            const url = new URL(a.href, location.origin);
            url.searchParams.delete('sp_atk');
            url.searchParams.delete('xptdk');
            a.href = url.pathname + url.search;
        } catch (e) {
        }
    }

    function overrideClick(a) {
        a.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            if (a.href) {
                window.location.href = a.href;
            }
        }, true);
    }

    function processElement(el) {
        if (!el) return;
        if (el.tagName.toLowerCase() === 'a') {
            cleanHref(el);
            overrideClick(el);
        } else {
            const link = el.querySelector('a[href]');
            if (link) {
                cleanHref(link);
                overrideClick(link);
            }
        }
    }

    function processLinks(root = document) {
        root.querySelectorAll(selectors.join(',')).forEach(processElement);
    }

    processLinks();

    const observer = new MutationObserver(mutations => {
        for (const { addedNodes } of mutations) {
            addedNodes.forEach(node => {
                if (node.nodeType !== 1) return;
                selectors.forEach(sel => {
                    if (node.matches(sel)) {
                        processElement(node);
                    }
                });
                processLinks(node);
            });
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();